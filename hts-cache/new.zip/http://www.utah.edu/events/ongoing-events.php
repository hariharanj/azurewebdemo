<!DOCTYPE HTML>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--><html lang="en" class="no-js"><!--<![endif]-->
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0">
      <title>Ongoing Events  - The University of Utah</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="breadcrumb" content="Ongoing Events">
      <meta name="robots" content="index,follow">
      <link rel="shortcut icon" href="//templates.utah.edu/_main-v2/_images/favicon.ico" type="image/x-icon">
      <link rel="apple-touch-icon-precomposed" href="//templates.utah.edu/_main-v2/_images/apple-touch-icon.png">
      <link href="//templates.utah.edu/_main-v2/_css/main.css" rel="stylesheet" type="text/css" media="all">
      <link href="/_css/custom-styles.css" rel="stylesheet" type="text/css" media="all">
      
      
      <!--[if lt IE 9]>
      <script src="//oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="//oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <link href="//templates.utah.edu/_main-v2/respond-proxy.html" id="respond-proxy" rel="respond-proxy">
      
      <link href="http://templates.utah.edu/_images/respond.proxy.gif" id="respond-redirect" rel="respond-redirect">
      <script src="/_scripts/respond.proxy.js"></script>
      <![endif]-->
      
      <script src="//templates.utah.edu/_main-v2/_scripts/vendor/modernizr-2.6.2.min.js"></script>
      <!-- Code to be included before the closing </head> tag can go here -->


</head>
   <body class="three-column-right nav-menu-wrap nav-tracking-off box-left-column box-main-content"><!-- Code to be included after the opening <body> tag can go here -->

<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-NNDTGR"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NNDTGR');</script>
<!-- End Google Tag Manager -->
      <div class="uu-page-wrapper">
         <header class="uu-header" role="banner">
            <div class="uu-container"><a href="#uu-skip-target" class="uu-skip-nav">Skip to Main Content</a><div class="uu-header-logo"><a href="/index.php"><img src="http://templates.utah.edu/_main-v2/_images/header/logo/uu-logo.png" alt="The University of Utah" /></a>
</div><form id="gsa-campus-search" action="http://gsa.search.utah.edu/search" method="get" name="search" role="search">
	<label for="gsa-searchbox" class="sr-only">Search Campus:</label>
	<input id="gsa-searchbox" type="text" class="gsa-campus" name="q" value="" title="enter search terms" />
	<input type="hidden" name="site" value="default_collection" />
	<input type="hidden" name="client" value="MainCampus" />
	<input type="hidden" name="output" value="xml_no_dtd" />
	<input type="hidden" name="proxystylesheet" value="MainCampus" />
	<input type="hidden" name="numgm" value="10" />
	<input id="gsa-searchbutton" type="image" name="btnG" src="//templates.utah.edu/_main-v2/_images/search/gsa_search_btn.png"  title="submit search" alt="submit search" />
</form>
               <nav class="uu-nav navbar navbar-inverse" role="navigation">
                  <h2 class="sr-only">Main Navigation</h2>
                  <div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#top-nav"><span class="sr-only">Toggle navigation</span><span class="toggle-text">Menu</span><span class="icon-bar-group"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></span></button></div>
                  <div class="collapse navbar-collapse" id="top-nav"><ul class="nav navbar-nav navbar-right">
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admissions</a>
      <ul class="dropdown-menu">
         <li>
            <a href="http://admissions.utah.edu/">Office of Admissions</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/apply/">Apply for Admission</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/apply/undergraduate/">Undergraduate</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/apply/graduate/">Graduate</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/apply/international/">International</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/visit/">Visit Campus</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Academics</a>
      <ul class="dropdown-menu">
         <li>
            <a href="/academics/">Academic Resources</a>
         </li>
         <li>
            <a href="/students/catalog.php">Catalogs, Schedules &amp; Calendar</a>
         </li>
         <li>
            <a href="/academics/colleges.php">Colleges &amp; Departments</a>
         </li>
         <li>
            <a href="http://advising.utah.edu/majors/a-z.php">Majors</a>
         </li>
         <li>
            <a href="http://gradschool.utah.edu">Graduate School</a>
         </li>
         <li>
            <a href="http://studentsuccess.utah.edu">Student Success</a>
         </li>
         <li>
            <a href="/libraries/index.php">Libraries</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">The Arts</a>
      <ul class="dropdown-menu">
         <li>
            <a href="/arts/">The Arts on Campus</a>
         </li>
         <li>
            <a href="/arts/events.php">upcoming events</a>
         </li>
         <li>
            <a href="/arts/academic.php">Academic Programs</a>
         </li>
         <li>
            <a href="/arts/professional.php">Professional Arts</a>
         </li>
         <li>
            <a href="/arts/youth.php">Youth Arts</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Global U</a>
      <ul class="dropdown-menu">
         <li>
            <a href="http://global.utah.edu">Office for Global Engagement</a>
         </li>
         <li>
            <a href="http://global.utah.edu/global-resources.html">Global Academic Programs</a>
         </li>
         <li>
            <a href="http://healthsciences.utah.edu/globalhealth/">Global Health</a>
         </li>
         <li>
            <a href="http://asiacampus.utah.edu">Asia Campus</a>
         </li>
         <li>
            <a href="http://ulink.utah.edu/s/1077/index.aspx?sid=1077&amp;gid=1&amp;pgid=717">International Alumni</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Health Care</a>
      <ul class="dropdown-menu">
         <li>
            <a href="http://healthcare.utah.edu/">For Patients</a>
         </li>
         <li>
            <a href="http://healthcare.utah.edu/fad/">Find a Physician</a>
         </li>
         <li>
            <a href="http://healthcare.utah.edu/hospital/">University Hospital</a>
         </li>
         <li>
            <a href="http://healthsciences.utah.edu/">Education &amp; Research</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Athletics</a>
      <ul class="dropdown-menu">
         <li>
            <a href="http://utahutes.cstv.com/">Utah Athletics</a>
         </li>
         <li>
            <a href="http://utahtickets.com">Buy Tickets</a>
         </li>
         <li>
            <a href="http://www.utahutes.com/calendar/events/">Schedule</a>
         </li>
         <li>
            <a href="http://www.crimsonclub.utah.edu">Crimson Club</a>
         </li>
         <li>
            <a href="http://ulink.utah.edu/s/1077/index.aspx?sid=1077&amp;gid=1&amp;pgid=941">The Muss</a>
         </li>
      </ul>
   </li>
</ul>
</div>
               </nav>
            </div>
            <div class="uu-header-title">
               <div class="uu-container"><!--<h2><a href="/">College or Department Website Title</a></h2>-->
</div>
            </div>
         </header>
         <div class="uu-breadcrumb">
            <div class="uu-container">
               <p class="sr-only">You are here:</p>
               <ol class="breadcrumb">
                  <li><a href="/">Home</a></li>
                  <li><a href="/events/">Events</a></li>
                  <li class="active">Ongoing Events</li>
               </ol>
            </div>
         </div>
         <main class="uu-main" role="main">
            <div class="uu-container">
               <div class="uu-main-top row" id="uu-skip-target">
                  <div class="uu-top-content">
                     <!-- CALENDAR MENU -->
                     <ul class="calendar-list">
                        <li><a href="/events/index.php">Events&nbsp;Calendar</a></li>
                        <li><a href="/events/featured-events.php">Featured&nbsp;Events</a></li>
                        <li class="current"><a href="/events/ongoing-events.php">Ongoing&nbsp;Events</a></li>
                        <li><a href="https://forms.utah.edu/events/submit.php">Submit&nbsp;Events</a></li>
                     </ul>
                     <h1 class="no-top-margin">Ongoing Events</h1>
                     <!-- END CALENDAR MENU -->
                  </div>
               </div>
               <div class="uu-main-bottom row">
                  <div class="uu-left-column">
                     <!-- CALENDAR (LEFT) --><script type="text/javascript" src="http://www.trumba.com/scripts/spuds.js">// 
// </script><script type="text/javascript">
$Trumba.addSpud({
webName: "university-of-utah-ongoing-events",
spudType : "datefinder" });
</script><br><script type="text/javascript">
$Trumba.addSpud({
webName: "university-of-utah-ongoing-events",
spudType : "searchlabeled" });
</script><br><script type="text/javascript">
$Trumba.addSpud({
webName: "university-of-utah-ongoing-events",
spudType : "filter" });
</script><br><script type="text/javascript">
$Trumba.addSpud({
webName: "university-of-utah-ongoing-events",
spudType : "filter" ,
spudConfig : "Events by Category" });
</script><br><script type="text/javascript">
$Trumba.addSpud({
webName: "university-of-utah-ongoing-events",
spudType : "filter",
spudConfig : "Events by Location" });
</script>
                     <!-- END CALENDAR (LEFT) --></div>
                  <div class="uu-main-column">
                     <div class="uu-main-content">
                        <!-- CALENDAR (RIGHT) --><script type="text/javascript">
$Trumba.addSpud({
webName: "university-of-utah-ongoing-events",
spudType : "tabchooser" });
</script><script type="text/javascript">
$Trumba.addSpud({
webName: "university-of-utah-ongoing-events",
spudType : "monthlist" });
</script><script type="text/javascript">
$Trumba.addSpud({
webName: "university-of-utah-ongoing-events",
spudType : "main" });
</script><noscript>Your browser must support JavaScript to view this content. Please enable JavaScript
                           in your browser settings then try again. 
                           	<br><a href="http://www.trumba.com">Events calendar powered by Trumba</a></noscript>
                        <!-- END CALENDAR (RIGHT) -->
                     </div>
                     <div class="row">
                        <div class="uu-main-column-2"></div>
                        <div class="uu-main-column-3"></div>
                     </div>
                  </div>
               </div>
            </div>
         </main>
         <footer class="uu-footer" role="contentinfo">
            <div class="uu-container">
               <div class="row">
<!-- FOOTER AREA 1 -->
<div class="col-xs-6 col-sm-3 col-lg-2">
	<h2>Who</h2>
	<ul>
		<li><a href="/future-students/">Future Students</a></li>
		<li><a href="/students/">Students</a></li>
		<li><a href="/faculty/">Faculty</a></li>
		<li><a href="/staff/">Staff</a></li>
		<li><a href="/visitors/">Visitors</a></li>
		<li><a href="https://www.alumni.utah.edu">Alumni</a></li>
		<li><a href="http://uteproud.utah.edu/">Ute Proud</a></li>
	</ul>
	</div>
	<!-- END FOOTER AREA 1 -->
	<!-- FOOTER AREA 2 -->
	<div class="col-xs-6 col-sm-3 col-lg-2">
		<h2>What</h2>
		<ul>
			<li><a href="http://research.utah.edu/">Research</a></li>
			<li><a href="/diversity/">Diversity</a></li>
			<li><a href="http://sustainability.utah.edu/">Sustainability</a></li>
			<li><a href="/community/index.php">Community</a></li>
			<li><a href="http://www.employment.utah.edu">Employment</a></li>
			<li><a href="http://admin.utah.edu">U Leadership</a></li>
			<li><a href="http://dps.utah.edu/">Campus Safety</a></li>
		</ul>
	</div>
	<!-- END FOOTER AREA 2 -->
	<!-- FOOTER AREA 3 -->
	<!-- Add the extra clearfix for only the required viewport -->
	<div class="clearfix visible-xs-block"></div>
	<div class="col-xs-6 col-sm-3 col-lg-2">
		<h2>Where</h2>
		<ul>
			<li><a href="/a-z/">A-Z Index</a></li>
			<li><a href="http://people.utah.edu/uWho/basic.hml">Directory</a></li>
			<li><a href="http://www.map.utah.edu/?WT.svl=map_topnav">Map</a></li>
			<li><a href="http://www.uofubus.com/">Shuttle Tracker</a></li>
			<li><a href="/about/">About The U</a></li>
			<li><a href="/events/">Events</a></li>
		</ul>
	</div>
	<!-- END FOOTER AREA 3 -->
	<!-- FOOTER AREA 4 -->
	<div class="col-xs-6 col-sm-3 col-lg-2">
		<h2>The Fine Print</h2>
		<ul>
			<li><a href="/nondiscrimination/">Nondiscrimination &amp; Accessibility</a></li>
			<li><a href="/disclaimer/">Disclaimer</a></li>
			<li><a href="/privacy/">Privacy</a></li>
			<li><a href="http://unews.utah.edu/primary-media-contacts/">Media Contacts</a></li>
			<li><a href="/contact/">Contact - Feedback</a></li>
			<li><span id="directedit"> </span></li>
		</ul>
	</div>
	<!-- END FOOTER AREA 4 -->
	<!-- FOOTER AREA 5 -->
	<div class="col-xs-12 col-lg-4">
		<div class="row">
			<div class="footer-logo col-sm-6 col-sm-offset-6 col-lg-12 col-lg-offset-0"><a href="http://imagineu.utah.edu/"><img src="/_images/imagine_u.png" alt="Imagine U: The University of Utah" /></a></div>
			<div class="col-xs-6">
				<ul class="socons">
					<li><a class="cis-link" title="CIS login" href="https://gate.acs.utah.edu/">CIS</a></li>
					<li><a class="umail-link" title="U-Mail" href="https://www.umail.utah.edu/">U-Mail</a></li>
					<li><a class="advising-link" title="Academic Advising Appointments" href="http://advising.utah.edu/academic-advising-appts.php">Academic Advising Appointments</a></li>
					<li><a class="facebook-link" title="facebook" href="http://www.facebook.com/universityofutah">facebook</a></li>
					<li><a class="twitter-link" title="twitter" href="http://twitter.com/uutah">twitter</a></li>
					<li><a class="instagram-link" title="instagram" href="https://www.instagram.com/universityofutah/">Instagram</a></li>
					<li><a class="youtube-link" title="youtube" href="http://youtube.com/theuniversityofutah">youtube</a></li>
				</ul>
				<p style="clear: both;"><a class="btn btn-primary btn-xs" href="http://togetherwereach.net/" role="button">Giving to the U</a></p>
			</div>
			<div class="col-xs-6">
				<p><a href="/">The University of Utah</a><br /> 201 Presidents Circle <br />Room 201 SLC, UT 84112 <br /> 801-581-7200</p>
				<p><small>&copy; 2016 The University of Utah <br /><a href="/credits.php">Credits &amp; Attributions</a></small></p>
			</div>
		</div>
	</div>
<!-- END FOOTER AREA 5 -->
</div>
            </div>
         </footer>
      </div><script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script><script>window.jQuery || document.write('<script src="//templates.utah.edu/_main-v2/_scripts/vendor/jquery-1.11.1.min.js"><\/script>')</script><script src="//templates.utah.edu/_main-v2/_scripts/vendor/bootstrap.min.js"></script><script src="//templates.utah.edu/_main-v2/_scripts/main.js"></script><script type="text/javascript" src="/_scripts/custom-scripts.js"></script>
      
      <script type="text/javascript" src="//templates.utah.edu/_main-v2/_scripts/directedit.js"></script><script type="text/javascript">
         <!--
				window.onload = function(){ directedit(); }
				//
			--></script>
      <!-- Code to be included before the closing </body> tag can go here -->
<div id="hidden">
         <a id="de" href="http://a.cms.omniupdate.com/10?skin=utah&amp;account=utah_home&amp;site=utah_home&amp;action=de&amp;path=/events/ongoing-events.pcf" >Last Updated: 4/27/16</a>
      </div>
   </body>
</html>