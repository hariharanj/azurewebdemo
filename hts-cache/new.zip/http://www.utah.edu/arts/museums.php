<!DOCTYPE HTML>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--><html lang="en" class="no-js"><!--<![endif]-->
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0">
      <title>Museums and Galleries - The Arts  - The University of Utah</title>
      <meta name="keywords" content="">
      <meta name="description" content="The University of Utah has one of the country's finest natural history museums and the state's arboretum, and it's apparent that campus is teeming with culture. ">
      <meta name="breadcrumb" content="Museums &amp; Galleries">
      <meta name="robots" content="index,follow">
      <link rel="shortcut icon" href="//templates.utah.edu/_main-v2/_images/favicon.ico" type="image/x-icon">
      <link rel="apple-touch-icon-precomposed" href="//templates.utah.edu/_main-v2/_images/apple-touch-icon.png">
      <link href="//templates.utah.edu/_main-v2/_css/main.css" rel="stylesheet" type="text/css" media="all">
      <link href="/_css/custom-styles.css" rel="stylesheet" type="text/css" media="all">
      
      
      <!--[if lt IE 9]>
      <script src="//oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="//oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <link href="//templates.utah.edu/_main-v2/respond-proxy.html" id="respond-proxy" rel="respond-proxy">
      
      <link href="http://templates.utah.edu/_images/respond.proxy.gif" id="respond-redirect" rel="respond-redirect">
      <script src="/_scripts/respond.proxy.js"></script>
      <![endif]-->
      
      <script src="//templates.utah.edu/_main-v2/_scripts/vendor/modernizr-2.6.2.min.js"></script>
      <!-- Code to be included before the closing </head> tag can go here -->


</head>
   <body class="three-column-left nav-menu-wrap nav-tracking-off"><!-- Code to be included after the opening <body> tag can go here -->

<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-NNDTGR"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NNDTGR');</script>
<!-- End Google Tag Manager -->
      <div class="uu-page-wrapper">
         <header class="uu-header" role="banner">
            <div class="uu-container"><a href="#uu-skip-target" class="uu-skip-nav">Skip to Main Content</a><div class="uu-header-logo"><a href="/index.php"><img src="http://templates.utah.edu/_main-v2/_images/header/logo/uu-logo.png" alt="The University of Utah" /></a>
</div><form id="gsa-campus-search" action="http://gsa.search.utah.edu/search" method="get" name="search" role="search">
	<label for="gsa-searchbox" class="sr-only">Search Campus:</label>
	<input id="gsa-searchbox" type="text" class="gsa-campus" name="q" value="" title="enter search terms" />
	<input type="hidden" name="site" value="default_collection" />
	<input type="hidden" name="client" value="MainCampus" />
	<input type="hidden" name="output" value="xml_no_dtd" />
	<input type="hidden" name="proxystylesheet" value="MainCampus" />
	<input type="hidden" name="numgm" value="10" />
	<input id="gsa-searchbutton" type="image" name="btnG" src="//templates.utah.edu/_main-v2/_images/search/gsa_search_btn.png"  title="submit search" alt="submit search" />
</form>
               <nav class="uu-nav navbar navbar-inverse" role="navigation">
                  <h2 class="sr-only">Main Navigation</h2>
                  <div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#top-nav"><span class="sr-only">Toggle navigation</span><span class="toggle-text">Menu</span><span class="icon-bar-group"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></span></button></div>
                  <div class="collapse navbar-collapse" id="top-nav"><ul class="nav navbar-nav navbar-right">
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admissions</a>
      <ul class="dropdown-menu">
         <li>
            <a href="http://admissions.utah.edu/">Office of Admissions</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/apply/">Apply for Admission</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/apply/undergraduate/">Undergraduate</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/apply/graduate/">Graduate</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/apply/international/">International</a>
         </li>
         <li>
            <a href="http://admissions.utah.edu/visit/">Visit Campus</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Academics</a>
      <ul class="dropdown-menu">
         <li>
            <a href="/academics/">Academic Resources</a>
         </li>
         <li>
            <a href="/students/catalog.php">Catalogs, Schedules &amp; Calendar</a>
         </li>
         <li>
            <a href="/academics/colleges.php">Colleges &amp; Departments</a>
         </li>
         <li>
            <a href="http://advising.utah.edu/majors/a-z.php">Majors</a>
         </li>
         <li>
            <a href="http://gradschool.utah.edu">Graduate School</a>
         </li>
         <li>
            <a href="http://studentsuccess.utah.edu">Student Success</a>
         </li>
         <li>
            <a href="/libraries/index.php">Libraries</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">The Arts</a>
      <ul class="dropdown-menu">
         <li>
            <a href="/arts/">The Arts on Campus</a>
         </li>
         <li>
            <a href="/arts/events.php">upcoming events</a>
         </li>
         <li>
            <a href="/arts/academic.php">Academic Programs</a>
         </li>
         <li>
            <a href="/arts/professional.php">Professional Arts</a>
         </li>
         <li>
            <a href="/arts/youth.php">Youth Arts</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Global U</a>
      <ul class="dropdown-menu">
         <li>
            <a href="http://global.utah.edu">Office for Global Engagement</a>
         </li>
         <li>
            <a href="http://global.utah.edu/global-resources.html">Global Academic Programs</a>
         </li>
         <li>
            <a href="http://healthsciences.utah.edu/globalhealth/">Global Health</a>
         </li>
         <li>
            <a href="http://asiacampus.utah.edu">Asia Campus</a>
         </li>
         <li>
            <a href="http://ulink.utah.edu/s/1077/index.aspx?sid=1077&amp;gid=1&amp;pgid=717">International Alumni</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Health Care</a>
      <ul class="dropdown-menu">
         <li>
            <a href="http://healthcare.utah.edu/">For Patients</a>
         </li>
         <li>
            <a href="http://healthcare.utah.edu/fad/">Find a Physician</a>
         </li>
         <li>
            <a href="http://healthcare.utah.edu/hospital/">University Hospital</a>
         </li>
         <li>
            <a href="http://healthsciences.utah.edu/">Education &amp; Research</a>
         </li>
      </ul>
   </li>
   <li class="dropdown ">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown">Athletics</a>
      <ul class="dropdown-menu">
         <li>
            <a href="http://utahutes.cstv.com/">Utah Athletics</a>
         </li>
         <li>
            <a href="http://utahtickets.com">Buy Tickets</a>
         </li>
         <li>
            <a href="http://www.utahutes.com/calendar/events/">Schedule</a>
         </li>
         <li>
            <a href="http://www.crimsonclub.utah.edu">Crimson Club</a>
         </li>
         <li>
            <a href="http://ulink.utah.edu/s/1077/index.aspx?sid=1077&amp;gid=1&amp;pgid=941">The Muss</a>
         </li>
      </ul>
   </li>
</ul>
</div>
               </nav>
            </div>
            <div class="uu-header-title">
               <div class="uu-container"><!--<h2><a href="/">College or Department Website Title</a></h2>-->
</div>
            </div>
         </header>
         <div class="uu-breadcrumb">
            <div class="uu-container">
               <p class="sr-only">You are here:</p>
               <ol class="breadcrumb">
                  <li><a href="/">Home</a></li>
                  <li><a href="/arts/">The Arts</a></li>
                  <li class="active">Museums &amp; Galleries</li>
               </ol>
            </div>
         </div>
         <main class="uu-main" role="main">
            <div class="uu-container">
               <div class="uu-main-top row" id="uu-skip-target">
                  <div class="uu-top-content">
                     <h1>The Arts — Museums &amp; Galleries</h1>
                  </div>
               </div>
               <div class="uu-main-bottom row">
                  <div class="uu-main-column">
                     <div class="uu-main-content">
                        <div class="panel">
                           <div class="panel-body">
                              <p>Looking for some inspiration? Try the state's visual fine arts museum. Or, if you
                                 require something more avant-garde, the work of students and faculty at the Gittins
                                 Gallery always stretches the canvas. Include one of the country's finest natural history
                                 museums and the state's arboretum, and it's apparent that campus is teeming with culture.
                              </p>
                           </div>
                        </div>
                        <div class="panel">
                           <div class="panel-body">
                              <div class="row">
                                 <div class="col-sm-3"><img class="img-margin-bottom-sm" src="/_images/arts/thmb-umfa.jpg" alt=""></div>
                                 <div class="col-sm-9">
                                    <h2>Utah Museum of Fine Arts</h2>
                                    <p><a class="btn btn-primary btn-float-right" role="button" href="http://umfa.utah.edu/">Learn More<span class="sr-only"> About Utah Museum of Fine Arts</span></a>The Utah Museum of Fine Arts (UMFA) provides fresh perspectives with regular exhibitions
                                       and a well-rounded permanent collection that spans 5,000 years of visual art forms
                                       from across the globe.
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="panel">
                           <div class="panel-body">
                              <div class="row">
                                 <div class="col-sm-3"><img class="img-margin-bottom-sm" src="/_images/arts/thmb-nhmu.jpg" alt=""></div>
                                 <div class="col-sm-9">
                                    <h2>Natural History Museum of Utah</h2>
                                    <p><a class="btn btn-primary btn-float-right" role="button" href="http://www.nhmu.utah.edu/">Learn More<span class="sr-only"> About Natural History Museum of Utah</span></a>Completed in 2011, the Natural History Museum's new facility (its previous home was
                                       the Thomas Building on Presidents Circle) glows from its perch on the Bonneville Shoreline
                                       Trail. But it has more than a pretty face. Critics from New York to L.A. have lauded
                                       it as one the premier museums devoted to the natural world.
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="panel">
                           <div class="panel-body">
                              <div class="row">
                                 <div class="col-sm-3"><img class="img-margin-bottom-sm" src="/_images/arts/thmb-redbutte.jpg" alt=""></div>
                                 <div class="col-sm-9">
                                    <h2>Red Butte Garden &amp; Arboretum</h2>
                                    <p><a class="btn btn-primary btn-float-right" role="button" href="http://www.redbuttegarden.org/">Learn More<span class="sr-only"> About Red Butte Garden &amp; Arboretum</span></a>With gardens and trails spread across 100 acres in the Wasatch foothills, Red Butte
                                       is a great place to get back in touch with nature. Though don't count on it being
                                       too quiet on certain summer evenings – Red Butte's outdoor concert series attracts
                                       top touring acts each year and definitely rocks the amphitheater at the mouth of Red
                                       Butte Canyon.
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="panel">
                           <div class="panel-body">
                              <div class="row">
                                 <div class="col-sm-3"><img class="img-margin-bottom-sm" src="/_images/arts/thmb-art-history.jpg" alt=""></div>
                                 <div class="col-sm-9">
                                    <h2>Art &amp; Art History Galleries</h2>
                                    <p><a class="btn btn-primary btn-float-right" role="button" href="http://www.art.utah.edu/index.php/galleries/">Learn More<span class="sr-only"> About Art &amp; Art History Galleries</span></a>Along with an array of online digital galleries featuring work from students and faculty,
                                       the College of Fine Arts is home to the physical Gittins Gallery found on the main
                                       floor of the Art Building.
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="uu-main-column-2"></div>
                        <div class="uu-main-column-3"></div>
                     </div>
                  </div>
                  <div class="uu-right-column">
                     <div class="panel">
                        <div class="panel-body panel-bg-dark text-center">
                           <h2 class="sr-only">Campus Links</h2>
                           <ul class="link-list icon-list">
                              <li><a href="/directions/" class="directions-link">Directions</a></li>
                              <li><a href="http://www.map.utah.edu/index.html" class="map-link">Campus Map</a></li>
                              <li><a href="http://www.map.utah.edu/?&amp;xmin=427436.2&amp;ymin=4511587.7&amp;xmax=431563.8&amp;ymax=4514212.3&amp;parkv=on&amp;aerial=off" class="parking-link">Parking on Campus</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="panel">
                        <div class="panel-body panel-bg-light text-center">
                           <h2 class="text-uppercase h4">Arts Events</h2>
                           <!-- Events Feed --><script type="text/javascript" src="http://www.trumba.com/scripts/spuds.js">//</script><script type="text/javascript">
				$Trumba.addSpud({
				webName: "university-of-utah-arts",
				spudType : "upcoming" ,
				teaserBase : "http://www.utah.edu/events/your-events.php?filterview=Arts" });
			</script><noscript><ul class="calendar"> 
<li><a href="http://www.utah.edu/events/index.php?trumbaEmbed=view%3devent%26eventid%3d120313415">Oct 06: Utah Ballet Fall Concert</a></li> 
<li><a href="http://www.utah.edu/events/index.php?trumbaEmbed=view%3devent%26eventid%3d119783718">Oct 06: ARTLandish | Guillermo Galindo: Sonic Border</a></li> 
<li><a href="http://www.utah.edu/events/index.php?trumbaEmbed=view%3devent%26eventid%3d120313645">Oct 07: Utah Ballet Fall Concert</a></li> 
<li><a href="http://www.utah.edu/events/index.php?trumbaEmbed=view%3devent%26eventid%3d119933592">Oct 07: Matt Haimovitz "A Moveable Feast: The Bach Suites"</a></li> 
<li><a href="http://www.utah.edu/events/index.php?trumbaEmbed=view%3devent%26eventid%3d120715417">Oct 08: Indian Art Market</a></li> 
<li><a href="http://www.utah.edu/events/your-events.php?filterview=Arts">More...</a></li> 
</ul> 
</noscript>
                           <!-- End Events Feed --><a class="btn btn-primary" href="/events/your-events.php?filterview=Arts">More Events</a></div>
                     </div>
                     <div class="panel">
                        <div class="panel-body text-center"><a href="http://thefinerpointscfa.com"><img class="auto-scale" src="/_images/arts/arts-finerpoints.png" alt="The Finer Points: Where the Arts Come Together"></a></div>
                     </div>
                     <div class="panel">
                        <div class="panel-body text-center"><img class="auto-scale" src="http://www.utah.edu/_images/arts/youth_education.png" alt=""><h2 class="text-uppercase h4">Youth Education</h2>
                           <p>Camps and classes for kids from grades K&nbsp;to&nbsp;12.</p><a class="btn btn-primary" href="http://continue.utah.edu/youth">Learn More<span class="sr-only"> About Youth Education</span></a></div>
                     </div>
                  </div>
               </div>
            </div>
         </main>
         <footer class="uu-footer" role="contentinfo">
            <div class="uu-container">
               <div class="row">
<!-- FOOTER AREA 1 -->
<div class="col-xs-6 col-sm-3 col-lg-2">
	<h2>Who</h2>
	<ul>
		<li><a href="/future-students/">Future Students</a></li>
		<li><a href="/students/">Students</a></li>
		<li><a href="/faculty/">Faculty</a></li>
		<li><a href="/staff/">Staff</a></li>
		<li><a href="/visitors/">Visitors</a></li>
		<li><a href="https://www.alumni.utah.edu">Alumni</a></li>
		<li><a href="http://uteproud.utah.edu/">Ute Proud</a></li>
	</ul>
	</div>
	<!-- END FOOTER AREA 1 -->
	<!-- FOOTER AREA 2 -->
	<div class="col-xs-6 col-sm-3 col-lg-2">
		<h2>What</h2>
		<ul>
			<li><a href="http://research.utah.edu/">Research</a></li>
			<li><a href="/diversity/">Diversity</a></li>
			<li><a href="http://sustainability.utah.edu/">Sustainability</a></li>
			<li><a href="/community/index.php">Community</a></li>
			<li><a href="http://www.employment.utah.edu">Employment</a></li>
			<li><a href="http://admin.utah.edu">U Leadership</a></li>
			<li><a href="http://dps.utah.edu/">Campus Safety</a></li>
		</ul>
	</div>
	<!-- END FOOTER AREA 2 -->
	<!-- FOOTER AREA 3 -->
	<!-- Add the extra clearfix for only the required viewport -->
	<div class="clearfix visible-xs-block"></div>
	<div class="col-xs-6 col-sm-3 col-lg-2">
		<h2>Where</h2>
		<ul>
			<li><a href="/a-z/">A-Z Index</a></li>
			<li><a href="http://people.utah.edu/uWho/basic.hml">Directory</a></li>
			<li><a href="http://www.map.utah.edu/?WT.svl=map_topnav">Map</a></li>
			<li><a href="http://www.uofubus.com/">Shuttle Tracker</a></li>
			<li><a href="/about/">About The U</a></li>
			<li><a href="/events/">Events</a></li>
		</ul>
	</div>
	<!-- END FOOTER AREA 3 -->
	<!-- FOOTER AREA 4 -->
	<div class="col-xs-6 col-sm-3 col-lg-2">
		<h2>The Fine Print</h2>
		<ul>
			<li><a href="/nondiscrimination/">Nondiscrimination &amp; Accessibility</a></li>
			<li><a href="/disclaimer/">Disclaimer</a></li>
			<li><a href="/privacy/">Privacy</a></li>
			<li><a href="http://unews.utah.edu/primary-media-contacts/">Media Contacts</a></li>
			<li><a href="/contact/">Contact - Feedback</a></li>
			<li><span id="directedit"> </span></li>
		</ul>
	</div>
	<!-- END FOOTER AREA 4 -->
	<!-- FOOTER AREA 5 -->
	<div class="col-xs-12 col-lg-4">
		<div class="row">
			<div class="footer-logo col-sm-6 col-sm-offset-6 col-lg-12 col-lg-offset-0"><a href="http://imagineu.utah.edu/"><img src="/_images/imagine_u.png" alt="Imagine U: The University of Utah" /></a></div>
			<div class="col-xs-6">
				<ul class="socons">
					<li><a class="cis-link" title="CIS login" href="https://gate.acs.utah.edu/">CIS</a></li>
					<li><a class="umail-link" title="U-Mail" href="https://www.umail.utah.edu/">U-Mail</a></li>
					<li><a class="advising-link" title="Academic Advising Appointments" href="http://advising.utah.edu/academic-advising-appts.php">Academic Advising Appointments</a></li>
					<li><a class="facebook-link" title="facebook" href="http://www.facebook.com/universityofutah">facebook</a></li>
					<li><a class="twitter-link" title="twitter" href="http://twitter.com/uutah">twitter</a></li>
					<li><a class="instagram-link" title="instagram" href="https://www.instagram.com/universityofutah/">Instagram</a></li>
					<li><a class="youtube-link" title="youtube" href="http://youtube.com/theuniversityofutah">youtube</a></li>
				</ul>
				<p style="clear: both;"><a class="btn btn-primary btn-xs" href="http://togetherwereach.net/" role="button">Giving to the U</a></p>
			</div>
			<div class="col-xs-6">
				<p><a href="/">The University of Utah</a><br /> 201 Presidents Circle <br />Room 201 SLC, UT 84112 <br /> 801-581-7200</p>
				<p><small>&copy; 2016 The University of Utah <br /><a href="/credits.php">Credits &amp; Attributions</a></small></p>
			</div>
		</div>
	</div>
<!-- END FOOTER AREA 5 -->
</div>
            </div>
         </footer>
      </div><script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script><script>window.jQuery || document.write('<script src="//templates.utah.edu/_main-v2/_scripts/vendor/jquery-1.11.1.min.js"><\/script>')</script><script src="//templates.utah.edu/_main-v2/_scripts/vendor/bootstrap.min.js"></script><script src="//templates.utah.edu/_main-v2/_scripts/main.js"></script><script type="text/javascript" src="/_scripts/custom-scripts.js"></script>
      
      <script type="text/javascript" src="//templates.utah.edu/_main-v2/_scripts/directedit.js"></script><script type="text/javascript">
         <!--
				window.onload = function(){ directedit(); }
				//
			--></script>
      <!-- Code to be included before the closing </body> tag can go here -->
<div id="hidden">
         <a id="de" href="http://a.cms.omniupdate.com/10?skin=utah&amp;account=utah_home&amp;site=utah_home&amp;action=de&amp;path=/arts/museums.pcf" >Last Updated: 4/27/16</a>
      </div>
   </body>
</html>